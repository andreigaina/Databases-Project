create trigger TRG_DATA_ACT
    before insert or update
    on ACTE
    for each row
BEGIN
IF( :new.data_act > SYSDATE)
THEN
RAISE_APPLICATION_ERROR( -20001,
'Data depunere acte invalida.' );
END IF;
END;
/

