create trigger TIPURI_ACTE_COD_TIP_ACT_TRG
    before insert
    on TIPURI_ACTE
    for each row
    when (new.cod_tip_act IS NULL)
BEGIN
    :new.cod_tip_act := tipuri_acte_cod_tip_act_seq.nextval;
END;
/

