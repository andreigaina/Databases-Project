create trigger CAMERE_ID_CAMERA_TRG
    before insert
    on CAMERE
    for each row
    when (new.id_camera IS NULL)
BEGIN
    :new.id_camera := camere_id_camera_seq.nextval;
END;
/

