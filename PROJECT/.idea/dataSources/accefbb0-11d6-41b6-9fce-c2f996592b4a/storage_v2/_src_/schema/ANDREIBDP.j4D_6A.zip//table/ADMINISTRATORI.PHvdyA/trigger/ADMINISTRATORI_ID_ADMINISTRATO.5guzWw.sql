create trigger ADMINISTRATORI_ID_ADMINISTRATO
    before insert
    on ADMINISTRATORI
    for each row
    when (new.id_administrator IS NULL)
BEGIN
    :new.id_administrator := administratori_id_administrato.nextval;
END;
/

