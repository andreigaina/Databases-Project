create trigger STUDENTI_NR_MATRICOL_TRG
    before insert
    on STUDENTI
    for each row
    when (new.nr_matricol IS NULL)
BEGIN
    :new.nr_matricol := studenti_nr_matricol_seq.nextval;
END;
/

